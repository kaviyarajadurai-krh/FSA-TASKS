package com.example.demo.api.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/users")
public class UserController {
	
	
		@GetMapping("/{id}")
		public String getUser(@PathVariable String id) {
			return "User Details for ID" +id+"(from identityservice)";
		}

}
