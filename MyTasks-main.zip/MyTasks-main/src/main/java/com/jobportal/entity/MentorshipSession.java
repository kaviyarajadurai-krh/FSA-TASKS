package com.jobportal.entity;

import com.jobportal.enums.MentorshipStatus;
import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "mentorship_sessions")
public class MentorshipSession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private MentorshipStatus status = MentorshipStatus.PENDING;

    private Double amountPaid;
    private String paymentTransactionId;

    @Column(length = 1000)
    private String notes;

    private LocalDateTime scheduledAt;

    @CreationTimestamp
    private LocalDateTime bookedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mentor_id", nullable = false)
    private User mentor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mentee_id", nullable = false)
    private User mentee;

    public MentorshipSession() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public MentorshipStatus getStatus() { return status; }
    public void setStatus(MentorshipStatus status) { this.status = status; }
    public Double getAmountPaid() { return amountPaid; }
    public void setAmountPaid(Double amountPaid) { this.amountPaid = amountPaid; }
    public String getPaymentTransactionId() { return paymentTransactionId; }
    public void setPaymentTransactionId(String paymentTransactionId) { this.paymentTransactionId = paymentTransactionId; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    public LocalDateTime getScheduledAt() { return scheduledAt; }
    public void setScheduledAt(LocalDateTime scheduledAt) { this.scheduledAt = scheduledAt; }
    public LocalDateTime getBookedAt() { return bookedAt; }
    public void setBookedAt(LocalDateTime bookedAt) { this.bookedAt = bookedAt; }
    public User getMentor() { return mentor; }
    public void setMentor(User mentor) { this.mentor = mentor; }
    public User getMentee() { return mentee; }
    public void setMentee(User mentee) { this.mentee = mentee; }

    public static MentorshipSessionBuilder builder() { return new MentorshipSessionBuilder(); }

    public static class MentorshipSessionBuilder {
        private MentorshipStatus status = MentorshipStatus.PENDING;
        private Double amountPaid;
        private String paymentTransactionId, notes;
        private LocalDateTime scheduledAt;
        private User mentor, mentee;

        public MentorshipSessionBuilder status(MentorshipStatus v) { this.status = v; return this; }
        public MentorshipSessionBuilder amountPaid(Double v) { this.amountPaid = v; return this; }
        public MentorshipSessionBuilder paymentTransactionId(String v) { this.paymentTransactionId = v; return this; }
        public MentorshipSessionBuilder notes(String v) { this.notes = v; return this; }
        public MentorshipSessionBuilder scheduledAt(LocalDateTime v) { this.scheduledAt = v; return this; }
        public MentorshipSessionBuilder mentor(User v) { this.mentor = v; return this; }
        public MentorshipSessionBuilder mentee(User v) { this.mentee = v; return this; }

        public MentorshipSession build() {
            MentorshipSession s = new MentorshipSession();
            s.status = this.status;
            s.amountPaid = this.amountPaid;
            s.paymentTransactionId = this.paymentTransactionId;
            s.notes = this.notes;
            s.scheduledAt = this.scheduledAt;
            s.mentor = this.mentor;
            s.mentee = this.mentee;
            return s;
        }
    }
}