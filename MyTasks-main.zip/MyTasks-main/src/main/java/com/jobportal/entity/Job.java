package com.jobportal.entity;

import com.jobportal.enums.CompanyType;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "jobs")
public class Job {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false)
    private String title;

    @NotBlank
    @Column(length = 5000, nullable = false)
    private String description;

    @NotBlank
    private String companyName;

    @NotBlank
    private String location;

    private String skillsRequired;
    private Integer experienceRequired;
    private String salaryRange;

    @Enumerated(EnumType.STRING)
    @NotNull
    private CompanyType companyType;

    private boolean active = true;

    @CreationTimestamp
    private LocalDateTime postedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "recruiter_id", nullable = false)
    private User recruiter;

    @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Application> applications;

    public Job() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getSkillsRequired() { return skillsRequired; }
    public void setSkillsRequired(String skillsRequired) { this.skillsRequired = skillsRequired; }
    public Integer getExperienceRequired() { return experienceRequired; }
    public void setExperienceRequired(Integer experienceRequired) { this.experienceRequired = experienceRequired; }
    public String getSalaryRange() { return salaryRange; }
    public void setSalaryRange(String salaryRange) { this.salaryRange = salaryRange; }
    public CompanyType getCompanyType() { return companyType; }
    public void setCompanyType(CompanyType companyType) { this.companyType = companyType; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
    public LocalDateTime getPostedAt() { return postedAt; }
    public void setPostedAt(LocalDateTime postedAt) { this.postedAt = postedAt; }
    public User getRecruiter() { return recruiter; }
    public void setRecruiter(User recruiter) { this.recruiter = recruiter; }
    public List<Application> getApplications() { return applications; }
    public void setApplications(List<Application> applications) { this.applications = applications; }

    public static JobBuilder builder() { return new JobBuilder(); }

    public static class JobBuilder {
        private String title, description, companyName, location, skillsRequired, salaryRange;
        private Integer experienceRequired;
        private CompanyType companyType;
        private boolean active = true;
        private User recruiter;

        public JobBuilder title(String v) { this.title = v; return this; }
        public JobBuilder description(String v) { this.description = v; return this; }
        public JobBuilder companyName(String v) { this.companyName = v; return this; }
        public JobBuilder location(String v) { this.location = v; return this; }
        public JobBuilder skillsRequired(String v) { this.skillsRequired = v; return this; }
        public JobBuilder salaryRange(String v) { this.salaryRange = v; return this; }
        public JobBuilder experienceRequired(Integer v) { this.experienceRequired = v; return this; }
        public JobBuilder companyType(CompanyType v) { this.companyType = v; return this; }
        public JobBuilder active(boolean v) { this.active = v; return this; }
        public JobBuilder recruiter(User v) { this.recruiter = v; return this; }

        public Job build() {
            Job j = new Job();
            j.title = this.title;
            j.description = this.description;
            j.companyName = this.companyName;
            j.location = this.location;
            j.skillsRequired = this.skillsRequired;
            j.salaryRange = this.salaryRange;
            j.experienceRequired = this.experienceRequired;
            j.companyType = this.companyType;
            j.active = this.active;
            j.recruiter = this.recruiter;
            return j;
        }
    }
}