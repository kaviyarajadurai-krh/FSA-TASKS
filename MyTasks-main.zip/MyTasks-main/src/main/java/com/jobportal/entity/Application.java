package com.jobportal.entity;

import com.jobportal.enums.ApplicationStatus;
import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "applications",
       uniqueConstraints = @UniqueConstraint(columnNames = {"job_id", "applicant_id"}))
public class Application {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ApplicationStatus status = ApplicationStatus.PENDING;

    @Column(length = 2000)
    private String coverLetter;

    private String resumeSnapshot;

    @CreationTimestamp
    private LocalDateTime appliedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_id", nullable = false)
    private Job job;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "applicant_id", nullable = false)
    private User applicant;

    public Application() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public ApplicationStatus getStatus() { return status; }
    public void setStatus(ApplicationStatus status) { this.status = status; }
    public String getCoverLetter() { return coverLetter; }
    public void setCoverLetter(String coverLetter) { this.coverLetter = coverLetter; }
    public String getResumeSnapshot() { return resumeSnapshot; }
    public void setResumeSnapshot(String resumeSnapshot) { this.resumeSnapshot = resumeSnapshot; }
    public LocalDateTime getAppliedAt() { return appliedAt; }
    public void setAppliedAt(LocalDateTime appliedAt) { this.appliedAt = appliedAt; }
    public Job getJob() { return job; }
    public void setJob(Job job) { this.job = job; }
    public User getApplicant() { return applicant; }
    public void setApplicant(User applicant) { this.applicant = applicant; }

    public static ApplicationBuilder builder() { return new ApplicationBuilder(); }

    public static class ApplicationBuilder {
        private ApplicationStatus status = ApplicationStatus.PENDING;
        private String coverLetter, resumeSnapshot;
        private Job job;
        private User applicant;

        public ApplicationBuilder status(ApplicationStatus v) { this.status = v; return this; }
        public ApplicationBuilder coverLetter(String v) { this.coverLetter = v; return this; }
        public ApplicationBuilder resumeSnapshot(String v) { this.resumeSnapshot = v; return this; }
        public ApplicationBuilder job(Job v) { this.job = v; return this; }
        public ApplicationBuilder applicant(User v) { this.applicant = v; return this; }

        public Application build() {
            Application a = new Application();
            a.status = this.status;
            a.coverLetter = this.coverLetter;
            a.resumeSnapshot = this.resumeSnapshot;
            a.job = this.job;
            a.applicant = this.applicant;
            return a;
        }
    }
}