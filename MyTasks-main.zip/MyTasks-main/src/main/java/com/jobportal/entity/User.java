package com.jobportal.entity;

import com.jobportal.enums.Role;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Size(min = 2, max = 100)
    @Column(name = "full_name", nullable = false)
    private String fullName;

    @Email
    @NotBlank
    @Column(unique = true, nullable = false)
    private String email;

    @NotBlank
    @Column(nullable = false)
    private String password;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    private String phone;
    private String location;
    private String headline;

    @Column(length = 1000)
    private String bio;

    private String skills;
    private String resumePath;
    private String profileImage;
    private String companyName;
    private Boolean mentorshipEnabled = false;
    private Double mentorshipFee;

    @CreationTimestamp
    private LocalDateTime createdAt;

    @OneToMany(mappedBy = "recruiter", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Job> postedJobs;

    @OneToMany(mappedBy = "applicant", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Application> applications;

    @OneToMany(mappedBy = "mentor", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<MentorshipSession> mentorshipSessionsOffered;

    @OneToMany(mappedBy = "mentee", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<MentorshipSession> mentorshipSessionsBooked;

    public User() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getHeadline() { return headline; }
    public void setHeadline(String headline) { this.headline = headline; }
    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
    public String getSkills() { return skills; }
    public void setSkills(String skills) { this.skills = skills; }
    public String getResumePath() { return resumePath; }
    public void setResumePath(String resumePath) { this.resumePath = resumePath; }
    public String getProfileImage() { return profileImage; }
    public void setProfileImage(String profileImage) { this.profileImage = profileImage; }
    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }
    public Boolean getMentorshipEnabled() { return mentorshipEnabled; }
    public void setMentorshipEnabled(Boolean mentorshipEnabled) { this.mentorshipEnabled = mentorshipEnabled; }
    public Double getMentorshipFee() { return mentorshipFee; }
    public void setMentorshipFee(Double mentorshipFee) { this.mentorshipFee = mentorshipFee; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public List<Job> getPostedJobs() { return postedJobs; }
    public void setPostedJobs(List<Job> postedJobs) { this.postedJobs = postedJobs; }
    public List<Application> getApplications() { return applications; }
    public void setApplications(List<Application> applications) { this.applications = applications; }

    public static UserBuilder builder() { return new UserBuilder(); }

    public static class UserBuilder {
        private String fullName, email, password, location, companyName;
        private Role role;
        private Boolean mentorshipEnabled = false;

        public UserBuilder fullName(String v) { this.fullName = v; return this; }
        public UserBuilder email(String v) { this.email = v; return this; }
        public UserBuilder password(String v) { this.password = v; return this; }
        public UserBuilder role(Role v) { this.role = v; return this; }
        public UserBuilder location(String v) { this.location = v; return this; }
        public UserBuilder companyName(String v) { this.companyName = v; return this; }
        public UserBuilder mentorshipEnabled(Boolean v) { this.mentorshipEnabled = v; return this; }

        public User build() {
            User u = new User();
            u.fullName = this.fullName;
            u.email = this.email;
            u.password = this.password;
            u.role = this.role;
            u.location = this.location;
            u.companyName = this.companyName;
            u.mentorshipEnabled = this.mentorshipEnabled;
            return u;
        }
    }
}