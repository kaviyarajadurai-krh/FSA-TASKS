package com.jobportal.service.impl;

import com.jobportal.entity.MentorshipSession;
import com.jobportal.entity.User;
import com.jobportal.enums.MentorshipStatus;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.MentorshipSessionRepository;
import com.jobportal.service.MentorshipService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class MentorshipServiceImpl implements MentorshipService {

    private final MentorshipSessionRepository mentorshipSessionRepository;

    public MentorshipServiceImpl(MentorshipSessionRepository mentorshipSessionRepository) {
        this.mentorshipSessionRepository = mentorshipSessionRepository;
    }

    @Override
    public MentorshipSession bookSession(User mentor, User mentee, LocalDateTime scheduledAt, String notes) {
        if (!mentor.getMentorshipEnabled()) {
            throw new IllegalStateException("This mentor is not accepting sessions.");
        }
        MentorshipSession session = MentorshipSession.builder()
                .mentor(mentor)
                .mentee(mentee)
                .scheduledAt(scheduledAt)
                .notes(notes)
                .amountPaid(mentor.getMentorshipFee())
                .paymentTransactionId("TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                .status(MentorshipStatus.PENDING)
                .build();
        return mentorshipSessionRepository.save(session);
    }

    @Override
    @Transactional(readOnly = true)
    public List<MentorshipSession> findByMentor(User mentor) {
        return mentorshipSessionRepository.findByMentor(mentor);
    }

    @Override
    @Transactional(readOnly = true)
    public List<MentorshipSession> findByMentee(User mentee) {
        return mentorshipSessionRepository.findByMentee(mentee);
    }

    @Override
    public MentorshipSession updateStatus(Long sessionId, MentorshipStatus status) {
        MentorshipSession session = mentorshipSessionRepository.findById(sessionId)
                .orElseThrow(() -> new ResourceNotFoundException("Session not found: " + sessionId));
        session.setStatus(status);
        return mentorshipSessionRepository.save(session);
    }

    @Override
    @Transactional(readOnly = true)
    public long countByMentor(User mentor) {
        return mentorshipSessionRepository.countByMentor(mentor);
    }
}