package com.jobportal.service;

import com.jobportal.dto.RegisterDto;
import com.jobportal.entity.User;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface UserService {
    User register(RegisterDto dto);
    User findByEmail(String email);
    User findById(Long id);
    User updateProfile(Long id, User updatedUser);
    String uploadResume(Long userId, MultipartFile file);
    List<User> findAllMentors();
    User updateMentorshipSettings(Long userId, boolean enabled, Double fee);
    boolean emailExists(String email);
}
