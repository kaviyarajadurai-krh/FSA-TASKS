package com.jobportal.service.impl;

import com.jobportal.dto.JobDto;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.enums.CompanyType;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.JobRepository;
import com.jobportal.service.JobService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class JobServiceImpl implements JobService {

    private final JobRepository jobRepository;

    public JobServiceImpl(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    @Override
    public Job postJob(JobDto dto, User recruiter) {
        Job job = Job.builder()
                .title(dto.getTitle())
                .description(dto.getDescription())
                .companyName(dto.getCompanyName())
                .location(dto.getLocation())
                .skillsRequired(dto.getSkillsRequired())
                .experienceRequired(dto.getExperienceRequired())
                .salaryRange(dto.getSalaryRange())
                .companyType(dto.getCompanyType())
                .active(true)
                .recruiter(recruiter)
                .build();
        return jobRepository.save(job);
    }

    @Override
    public Job updateJob(Long jobId, JobDto dto) {
        Job job = findById(jobId);
        job.setTitle(dto.getTitle());
        job.setDescription(dto.getDescription());
        job.setCompanyName(dto.getCompanyName());
        job.setLocation(dto.getLocation());
        job.setSkillsRequired(dto.getSkillsRequired());
        job.setExperienceRequired(dto.getExperienceRequired());
        job.setSalaryRange(dto.getSalaryRange());
        job.setCompanyType(dto.getCompanyType());
        return jobRepository.save(job);
    }

    @Override
    public void deleteJob(Long jobId) {
        Job job = findById(jobId);
        job.setActive(false);
        jobRepository.save(job);
    }

    @Override
    @Transactional(readOnly = true)
    public Job findById(Long id) {
        return jobRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Job not found with id: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<Job> findAllActive() {
        return jobRepository.findByActiveTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Job> findByRecruiter(User recruiter) {
        return jobRepository.findByRecruiter(recruiter);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Job> searchJobs(String keyword, String location, CompanyType companyType, Integer experience) {
        return jobRepository.searchJobs(
                (keyword != null && !keyword.isBlank()) ? keyword : null,
                (location != null && !location.isBlank()) ? location : null,
                companyType,
                experience
        );
    }

    @Override
    @Transactional(readOnly = true)
    public List<Job> findLatestJobs() {
        return jobRepository.findTop6ByActiveTrueOrderByPostedAtDesc();
    }

    @Override
    @Transactional(readOnly = true)
    public long countActiveJobsByRecruiter(User recruiter) {
        return jobRepository.countByRecruiterAndActiveTrue(recruiter);
    }
}