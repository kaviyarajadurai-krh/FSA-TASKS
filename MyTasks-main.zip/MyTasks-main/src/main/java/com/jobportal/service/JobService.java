package com.jobportal.service;

import com.jobportal.dto.JobDto;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.enums.CompanyType;

import java.util.List;

public interface JobService {
    Job postJob(JobDto dto, User recruiter);
    Job updateJob(Long jobId, JobDto dto);
    void deleteJob(Long jobId);
    Job findById(Long id);
    List<Job> findAllActive();
    List<Job> findByRecruiter(User recruiter);
    List<Job> searchJobs(String keyword, String location, CompanyType companyType, Integer experience);
    List<Job> findLatestJobs();
    long countActiveJobsByRecruiter(User recruiter);
}
