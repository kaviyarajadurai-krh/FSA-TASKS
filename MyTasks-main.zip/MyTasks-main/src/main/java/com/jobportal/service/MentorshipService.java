package com.jobportal.service;

import com.jobportal.entity.MentorshipSession;
import com.jobportal.entity.User;
import com.jobportal.enums.MentorshipStatus;

import java.time.LocalDateTime;
import java.util.List;

public interface MentorshipService {
    MentorshipSession bookSession(User mentor, User mentee, LocalDateTime scheduledAt, String notes);
    List<MentorshipSession> findByMentor(User mentor);
    List<MentorshipSession> findByMentee(User mentee);
    MentorshipSession updateStatus(Long sessionId, MentorshipStatus status);
    long countByMentor(User mentor);
}
