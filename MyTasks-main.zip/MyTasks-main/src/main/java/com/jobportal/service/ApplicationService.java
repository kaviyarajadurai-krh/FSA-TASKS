package com.jobportal.service;

import com.jobportal.entity.Application;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.enums.ApplicationStatus;

import java.util.List;

public interface ApplicationService {
    Application apply(Job job, User applicant, String coverLetter);
    List<Application> findByJob(Job job);
    List<Application> findByApplicant(User applicant);
    Application updateStatus(Long applicationId, ApplicationStatus status);
    boolean hasApplied(Job job, User applicant);
    long countByApplicant(User applicant);
    long countPendingForRecruiter(User recruiter);
    List<Application> findByRecruiter(User recruiter);
}
