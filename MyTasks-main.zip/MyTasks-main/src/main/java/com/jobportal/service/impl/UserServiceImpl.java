package com.jobportal.service.impl;

import com.jobportal.dto.RegisterDto;
import com.jobportal.entity.User;
import com.jobportal.enums.Role;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.UserRepository;
import com.jobportal.service.UserService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${file.upload.dir}")
    private String uploadDir;

    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public User register(RegisterDto dto) {
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("Email already registered: " + dto.getEmail());
        }
        User user = User.builder()
                .fullName(dto.getFullName())
                .email(dto.getEmail())
                .password(passwordEncoder.encode(dto.getPassword()))
                .role(dto.getRole())
                .location(dto.getLocation())
                .companyName(dto.getCompanyName())
                .mentorshipEnabled(false)
                .build();
        return userRepository.save(user);
    }

    @Override
    @Transactional(readOnly = true)
    public User findByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }

    @Override
    @Transactional(readOnly = true)
    public User findById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }

    @Override
    public User updateProfile(Long id, User updatedUser) {
        User existing = findById(id);
        existing.setFullName(updatedUser.getFullName());
        existing.setPhone(updatedUser.getPhone());
        existing.setLocation(updatedUser.getLocation());
        existing.setHeadline(updatedUser.getHeadline());
        existing.setBio(updatedUser.getBio());
        existing.setSkills(updatedUser.getSkills());
        if (existing.getRole() == Role.ROLE_RECRUITER) {
            existing.setCompanyName(updatedUser.getCompanyName());
        }
        return userRepository.save(existing);
    }

    @Override
    public String uploadResume(Long userId, MultipartFile file) {
        User user = findById(userId);
        try {
            Path uploadPath = Paths.get(uploadDir);
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }
            String filename = UUID.randomUUID() + "_" + file.getOriginalFilename();
            Path filePath = uploadPath.resolve(filename);
            Files.copy(file.getInputStream(), filePath);
            user.setResumePath(filename);
            userRepository.save(user);
            return filename;
        } catch (IOException e) {
            throw new RuntimeException("Failed to upload resume", e);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<User> findAllMentors() {
        return userRepository.findByRoleAndMentorshipEnabledTrue(Role.ROLE_RECRUITER);
    }

    @Override
    public User updateMentorshipSettings(Long userId, boolean enabled, Double fee) {
        User user = findById(userId);
        user.setMentorshipEnabled(enabled);
        user.setMentorshipFee(fee);
        return userRepository.save(user);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean emailExists(String email) {
        return userRepository.existsByEmail(email);
    }
}