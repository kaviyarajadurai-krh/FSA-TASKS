package com.jobportal.service.impl;

import com.jobportal.entity.Application;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.enums.ApplicationStatus;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.ApplicationRepository;
import com.jobportal.service.ApplicationService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ApplicationServiceImpl implements ApplicationService {

    private final ApplicationRepository applicationRepository;

    public ApplicationServiceImpl(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }

    @Override
    public Application apply(Job job, User applicant, String coverLetter) {
        if (applicationRepository.existsByJobAndApplicant(job, applicant)) {
            throw new IllegalStateException("You have already applied for this job.");
        }
        Application application = Application.builder()
                .job(job)
                .applicant(applicant)
                .coverLetter(coverLetter)
                .resumeSnapshot(applicant.getResumePath())
                .status(ApplicationStatus.PENDING)
                .build();
        return applicationRepository.save(application);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Application> findByJob(Job job) {
        return applicationRepository.findByJob(job);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Application> findByApplicant(User applicant) {
        return applicationRepository.findByApplicant(applicant);
    }

    @Override
    public Application updateStatus(Long applicationId, ApplicationStatus status) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found: " + applicationId));
        application.setStatus(status);
        return applicationRepository.save(application);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean hasApplied(Job job, User applicant) {
        return applicationRepository.existsByJobAndApplicant(job, applicant);
    }

    @Override
    @Transactional(readOnly = true)
    public long countByApplicant(User applicant) {
        return applicationRepository.countByApplicant(applicant);
    }

    @Override
    @Transactional(readOnly = true)
    public long countPendingForRecruiter(User recruiter) {
        return applicationRepository.countByJobRecruiterAndStatus(recruiter, ApplicationStatus.PENDING);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Application> findByRecruiter(User recruiter) {
        return applicationRepository.findByJobRecruiter(recruiter);
    }
}