package com.jobportal.repository;

import com.jobportal.entity.User;
import com.jobportal.enums.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // Find user by email (used for login)
    Optional<User> findByEmail(String email);

    // Check if email already exists
    boolean existsByEmail(String email);

    // Find all users by role
    List<User> findByRole(Role role);

    // Find recruiters with mentorship enabled
    List<User> findByRoleAndMentorshipEnabledTrue(Role role);

    // Search recruiters by company name
    List<User> findByRoleAndCompanyNameContainingIgnoreCase(Role role, String companyName);

    // Count by role
    long countByRole(Role role);
}
