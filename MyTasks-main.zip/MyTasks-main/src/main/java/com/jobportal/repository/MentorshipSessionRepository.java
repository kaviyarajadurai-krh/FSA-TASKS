package com.jobportal.repository;

import com.jobportal.entity.MentorshipSession;
import com.jobportal.entity.User;
import com.jobportal.enums.MentorshipStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MentorshipSessionRepository extends JpaRepository<MentorshipSession, Long> {

    // Sessions booked with a mentor
    List<MentorshipSession> findByMentor(User mentor);

    // Sessions booked by a mentee
    List<MentorshipSession> findByMentee(User mentee);

    // Sessions by status
    List<MentorshipSession> findByMentorAndStatus(User mentor, MentorshipStatus status);

    // Count sessions for a mentor
    long countByMentor(User mentor);

    // Count sessions for a mentee
    long countByMentee(User mentee);
}
