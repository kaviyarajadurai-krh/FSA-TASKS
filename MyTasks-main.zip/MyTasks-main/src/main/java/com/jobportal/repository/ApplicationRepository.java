package com.jobportal.repository;

import com.jobportal.entity.Application;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.enums.ApplicationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {

    // All applications for a specific job (recruiter view)
    List<Application> findByJob(Job job);

    // All applications by a specific user (seeker view)
    List<Application> findByApplicant(User applicant);

    // Check if user already applied to a job
    boolean existsByJobAndApplicant(Job job, User applicant);

    // Find specific application by job and applicant
    Optional<Application> findByJobAndApplicant(Job job, User applicant);

    // Count applications by status for a job
    long countByJobAndStatus(Job job, ApplicationStatus status);

    // Total applications by a seeker
    long countByApplicant(User applicant);

    // Applications for all jobs of a recruiter
    List<Application> findByJobRecruiter(User recruiter);

    // Count new (pending) applications for recruiter
    long countByJobRecruiterAndStatus(User recruiter, ApplicationStatus status);
}
