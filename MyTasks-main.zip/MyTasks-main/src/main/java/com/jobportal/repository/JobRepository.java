package com.jobportal.repository;

import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.enums.CompanyType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JobRepository extends JpaRepository<Job, Long> {

    // All active jobs for listing
    List<Job> findByActiveTrue();

    // Jobs by recruiter (ORM: one-to-many)
    List<Job> findByRecruiter(User recruiter);

    // Search by title keyword
    List<Job> findByActiveTrueAndTitleContainingIgnoreCase(String keyword);

    // Filter by location
    List<Job> findByActiveTrueAndLocationContainingIgnoreCase(String location);

    // Filter by company type
    List<Job> findByActiveTrueAndCompanyType(CompanyType companyType);

    // Multi-filter with JPQL query (no raw SQL)
    @Query("SELECT j FROM Job j WHERE j.active = true " +
           "AND (:keyword IS NULL OR LOWER(j.title) LIKE LOWER(CONCAT('%', :keyword, '%'))) " +
           "AND (:location IS NULL OR LOWER(j.location) LIKE LOWER(CONCAT('%', :location, '%'))) " +
           "AND (:companyType IS NULL OR j.companyType = :companyType) " +
           "AND (:experience IS NULL OR j.experienceRequired <= :experience) " +
           "ORDER BY j.postedAt DESC")
    List<Job> searchJobs(@Param("keyword") String keyword,
                         @Param("location") String location,
                         @Param("companyType") CompanyType companyType,
                         @Param("experience") Integer experience);

    // Count active jobs by recruiter
    long countByRecruiterAndActiveTrue(User recruiter);

    // Latest 6 jobs for dashboard
    List<Job> findTop6ByActiveTrueOrderByPostedAtDesc();
}
