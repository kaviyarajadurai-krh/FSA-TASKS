package com.jobportal.enums;

public enum Role {
    ROLE_JOB_SEEKER,
    ROLE_RECRUITER
}
