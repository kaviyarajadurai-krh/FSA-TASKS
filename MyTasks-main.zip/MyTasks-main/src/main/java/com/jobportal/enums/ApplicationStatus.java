package com.jobportal.enums;

public enum ApplicationStatus {
    PENDING,
    SHORTLISTED,
    REJECTED,
    HIRED
}
