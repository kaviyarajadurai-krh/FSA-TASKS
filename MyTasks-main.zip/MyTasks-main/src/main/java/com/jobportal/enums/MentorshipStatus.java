package com.jobportal.enums;

public enum MentorshipStatus {
    PENDING,
    CONFIRMED,
    COMPLETED,
    CANCELLED
}
