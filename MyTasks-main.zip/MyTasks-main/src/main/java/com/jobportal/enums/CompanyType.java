package com.jobportal.enums;

public enum CompanyType {
    IT,
    PRODUCT_BASED,
    MNC,
    STARTUP
}
