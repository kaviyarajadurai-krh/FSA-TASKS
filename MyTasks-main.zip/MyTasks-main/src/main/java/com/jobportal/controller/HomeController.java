package com.jobportal.controller;

import com.jobportal.service.JobService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    private final JobService jobService;

    public HomeController(JobService jobService) {
        this.jobService = jobService;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("latestJobs", jobService.findLatestJobs());
        return "shared/home";
    }

    @GetMapping("/jobs")
    public String publicJobs(Model model) {
        model.addAttribute("jobs", jobService.findAllActive());
        return "shared/public-jobs";
    }
}