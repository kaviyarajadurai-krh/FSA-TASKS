package com.jobportal.controller;

import com.jobportal.dto.JobDto;
import com.jobportal.entity.User;
import com.jobportal.enums.ApplicationStatus;
import com.jobportal.enums.CompanyType;
import com.jobportal.enums.MentorshipStatus;
import com.jobportal.service.ApplicationService;
import com.jobportal.service.JobService;
import com.jobportal.service.MentorshipService;
import com.jobportal.service.UserService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/recruiter")
public class RecruiterController {

    private final UserService userService;
    private final JobService jobService;
    private final ApplicationService applicationService;
    private final MentorshipService mentorshipService;

    public RecruiterController(UserService userService, JobService jobService,
                                ApplicationService applicationService, MentorshipService mentorshipService) {
        this.userService = userService;
        this.jobService = jobService;
        this.applicationService = applicationService;
        this.mentorshipService = mentorshipService;
    }

    private User getCurrentUser(UserDetails userDetails) {
        return userService.findByEmail(userDetails.getUsername());
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User recruiter = getCurrentUser(userDetails);
        model.addAttribute("user", recruiter);
        model.addAttribute("totalJobs", jobService.countActiveJobsByRecruiter(recruiter));
        model.addAttribute("totalApplications", applicationService.findByRecruiter(recruiter).size());
        model.addAttribute("pendingApplications", applicationService.countPendingForRecruiter(recruiter));
        model.addAttribute("myJobs", jobService.findByRecruiter(recruiter));
        model.addAttribute("mentorSessions", mentorshipService.countByMentor(recruiter));
        return "recruiter/dashboard";
    }

    @GetMapping("/profile")
    public String profilePage(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        model.addAttribute("user", getCurrentUser(userDetails));
        return "recruiter/profile";
    }

    @PostMapping("/profile/update")
    public String updateProfile(@AuthenticationPrincipal UserDetails userDetails,
                                @ModelAttribute User updatedUser,
                                RedirectAttributes redirectAttributes) {
        User recruiter = getCurrentUser(userDetails);
        userService.updateProfile(recruiter.getId(), updatedUser);
        redirectAttributes.addFlashAttribute("successMessage", "Profile updated!");
        return "redirect:/recruiter/profile";
    }

    @GetMapping("/jobs")
    public String myJobs(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User recruiter = getCurrentUser(userDetails);
        model.addAttribute("user", recruiter);
        model.addAttribute("jobs", jobService.findByRecruiter(recruiter));
        return "recruiter/jobs";
    }

    @GetMapping("/jobs/new")
    public String newJobForm(Model model) {
        model.addAttribute("jobDto", new JobDto());
        model.addAttribute("companyTypes", CompanyType.values());
        return "recruiter/job-form";
    }

    @PostMapping("/jobs/new")
    public String postJob(@Valid @ModelAttribute JobDto jobDto,
                          BindingResult result,
                          @AuthenticationPrincipal UserDetails userDetails,
                          Model model,
                          RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            model.addAttribute("companyTypes", CompanyType.values());
            return "recruiter/job-form";
        }
        User recruiter = getCurrentUser(userDetails);
        jobService.postJob(jobDto, recruiter);
        redirectAttributes.addFlashAttribute("successMessage", "Job posted successfully!");
        return "redirect:/recruiter/jobs";
    }

    @GetMapping("/jobs/{id}/edit")
    public String editJobForm(@PathVariable Long id, Model model) {
        var job = jobService.findById(id);
        JobDto dto = new JobDto();
        dto.setTitle(job.getTitle());
        dto.setDescription(job.getDescription());
        dto.setCompanyName(job.getCompanyName());
        dto.setLocation(job.getLocation());
        dto.setSkillsRequired(job.getSkillsRequired());
        dto.setExperienceRequired(job.getExperienceRequired());
        dto.setSalaryRange(job.getSalaryRange());
        dto.setCompanyType(job.getCompanyType());
        model.addAttribute("jobDto", dto);
        model.addAttribute("jobId", id);
        model.addAttribute("companyTypes", CompanyType.values());
        return "recruiter/job-form";
    }

    @PostMapping("/jobs/{id}/edit")
    public String updateJob(@PathVariable Long id,
                            @Valid @ModelAttribute JobDto jobDto,
                            BindingResult result,
                            Model model,
                            RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            model.addAttribute("companyTypes", CompanyType.values());
            model.addAttribute("jobId", id);
            return "recruiter/job-form";
        }
        jobService.updateJob(id, jobDto);
        redirectAttributes.addFlashAttribute("successMessage", "Job updated successfully!");
        return "redirect:/recruiter/jobs";
    }

    @PostMapping("/jobs/{id}/delete")
    public String deleteJob(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        jobService.deleteJob(id);
        redirectAttributes.addFlashAttribute("successMessage", "Job removed.");
        return "redirect:/recruiter/jobs";
    }

    @GetMapping("/jobs/{id}/applicants")
    public String viewApplicants(@PathVariable Long id,
                                 @AuthenticationPrincipal UserDetails userDetails,
                                 Model model) {
        User recruiter = getCurrentUser(userDetails);
        var job = jobService.findById(id);
        model.addAttribute("user", recruiter);
        model.addAttribute("job", job);
        model.addAttribute("applications", applicationService.findByJob(job));
        model.addAttribute("statuses", ApplicationStatus.values());
        return "recruiter/applicants";
    }

    @PostMapping("/applications/{id}/status")
    public String updateApplicationStatus(@PathVariable Long id,
                                          @RequestParam ApplicationStatus status,
                                          @RequestParam Long jobId,
                                          RedirectAttributes redirectAttributes) {
        applicationService.updateStatus(id, status);
        redirectAttributes.addFlashAttribute("successMessage", "Status updated to " + status.name());
        return "redirect:/recruiter/jobs/" + jobId + "/applicants";
    }

    @GetMapping("/mentorship")
    public String mentorshipSettings(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User recruiter = getCurrentUser(userDetails);
        model.addAttribute("user", recruiter);
        model.addAttribute("sessions", mentorshipService.findByMentor(recruiter));
        model.addAttribute("statuses", MentorshipStatus.values());
        return "recruiter/mentorship";
    }

    @PostMapping("/mentorship/settings")
    public String updateMentorshipSettings(@AuthenticationPrincipal UserDetails userDetails,
                                           @RequestParam boolean enabled,
                                           @RequestParam(required = false) Double fee,
                                           RedirectAttributes redirectAttributes) {
        User recruiter = getCurrentUser(userDetails);
        userService.updateMentorshipSettings(recruiter.getId(), enabled, fee);
        redirectAttributes.addFlashAttribute("successMessage", "Mentorship settings updated!");
        return "redirect:/recruiter/mentorship";
    }

    @PostMapping("/mentorship/sessions/{id}/status")
    public String updateSessionStatus(@PathVariable Long id,
                                      @RequestParam MentorshipStatus status,
                                      RedirectAttributes redirectAttributes) {
        mentorshipService.updateStatus(id, status);
        redirectAttributes.addFlashAttribute("successMessage", "Session status updated.");
        return "redirect:/recruiter/mentorship";
    }
}