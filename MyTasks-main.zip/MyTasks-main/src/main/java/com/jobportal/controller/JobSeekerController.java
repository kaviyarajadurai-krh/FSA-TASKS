package com.jobportal.controller;

import com.jobportal.entity.User;
import com.jobportal.enums.CompanyType;
import com.jobportal.service.ApplicationService;
import com.jobportal.service.JobService;
import com.jobportal.service.MentorshipService;
import com.jobportal.service.UserService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;

@Controller
@RequestMapping("/seeker")
public class JobSeekerController {

    private final UserService userService;
    private final JobService jobService;
    private final ApplicationService applicationService;
    private final MentorshipService mentorshipService;

    public JobSeekerController(UserService userService, JobService jobService,
                                ApplicationService applicationService, MentorshipService mentorshipService) {
        this.userService = userService;
        this.jobService = jobService;
        this.applicationService = applicationService;
        this.mentorshipService = mentorshipService;
    }

    private User getCurrentUser(UserDetails userDetails) {
        return userService.findByEmail(userDetails.getUsername());
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User seeker = getCurrentUser(userDetails);
        model.addAttribute("user", seeker);
        model.addAttribute("totalApplications", applicationService.countByApplicant(seeker));
        model.addAttribute("myApplications", applicationService.findByApplicant(seeker));
        model.addAttribute("latestJobs", jobService.findLatestJobs());
        return "jobseeker/dashboard";
    }

    @GetMapping("/profile")
    public String profilePage(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        model.addAttribute("user", getCurrentUser(userDetails));
        return "jobseeker/profile";
    }

    @PostMapping("/profile/update")
    public String updateProfile(@AuthenticationPrincipal UserDetails userDetails,
                                @ModelAttribute User updatedUser,
                                RedirectAttributes redirectAttributes) {
        User seeker = getCurrentUser(userDetails);
        userService.updateProfile(seeker.getId(), updatedUser);
        redirectAttributes.addFlashAttribute("successMessage", "Profile updated successfully!");
        return "redirect:/seeker/profile";
    }

    @PostMapping("/profile/resume")
    public String uploadResume(@AuthenticationPrincipal UserDetails userDetails,
                               @RequestParam("resume") MultipartFile file,
                               RedirectAttributes redirectAttributes) {
        User seeker = getCurrentUser(userDetails);
        if (file.isEmpty()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please select a file.");
            return "redirect:/seeker/profile";
        }
        userService.uploadResume(seeker.getId(), file);
        redirectAttributes.addFlashAttribute("successMessage", "Resume uploaded successfully!");
        return "redirect:/seeker/profile";
    }

    @GetMapping("/jobs")
    public String browseJobs(@AuthenticationPrincipal UserDetails userDetails,
                             @RequestParam(required = false) String keyword,
                             @RequestParam(required = false) String location,
                             @RequestParam(required = false) CompanyType companyType,
                             @RequestParam(required = false) Integer experience,
                             Model model) {
        User seeker = getCurrentUser(userDetails);
        var jobs = jobService.searchJobs(keyword, location, companyType, experience);
        model.addAttribute("user", seeker);
        model.addAttribute("jobs", jobs);
        model.addAttribute("keyword", keyword);
        model.addAttribute("location", location);
        model.addAttribute("selectedType", companyType);
        model.addAttribute("experience", experience);
        model.addAttribute("companyTypes", CompanyType.values());
        return "jobseeker/jobs";
    }

    @GetMapping("/jobs/{id}")
    public String jobDetail(@PathVariable Long id,
                            @AuthenticationPrincipal UserDetails userDetails,
                            Model model) {
        User seeker = getCurrentUser(userDetails);
        var job = jobService.findById(id);
        model.addAttribute("job", job);
        model.addAttribute("user", seeker);
        model.addAttribute("hasApplied", applicationService.hasApplied(job, seeker));
        return "jobseeker/job-detail";
    }

    @PostMapping("/jobs/{id}/apply")
    public String applyForJob(@PathVariable Long id,
                              @AuthenticationPrincipal UserDetails userDetails,
                              @RequestParam(required = false) String coverLetter,
                              RedirectAttributes redirectAttributes) {
        User seeker = getCurrentUser(userDetails);
        var job = jobService.findById(id);
        applicationService.apply(job, seeker, coverLetter);
        redirectAttributes.addFlashAttribute("successMessage", "Application submitted successfully!");
        return "redirect:/seeker/jobs/" + id;
    }

    @GetMapping("/applications")
    public String myApplications(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User seeker = getCurrentUser(userDetails);
        model.addAttribute("user", seeker);
        model.addAttribute("applications", applicationService.findByApplicant(seeker));
        return "jobseeker/applications";
    }

    @GetMapping("/mentorship")
    public String mentorshipPage(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User seeker = getCurrentUser(userDetails);
        model.addAttribute("user", seeker);
        model.addAttribute("mentors", userService.findAllMentors());
        model.addAttribute("mySessions", mentorshipService.findByMentee(seeker));
        return "jobseeker/mentorship";
    }

    @PostMapping("/mentorship/book/{mentorId}")
    public String bookSession(@PathVariable Long mentorId,
                              @AuthenticationPrincipal UserDetails userDetails,
                              @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime scheduledAt,
                              @RequestParam(required = false) String notes,
                              RedirectAttributes redirectAttributes) {
        User seeker = getCurrentUser(userDetails);
        User mentor = userService.findById(mentorId);
        mentorshipService.bookSession(mentor, seeker, scheduledAt, notes);
        redirectAttributes.addFlashAttribute("successMessage",
                "Session booked! Payment of ₹" + mentor.getMentorshipFee() + " processed successfully.");
        return "redirect:/seeker/mentorship";
    }
}